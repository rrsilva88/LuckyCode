<?php
	/**
	 * Template name: 6. Catalog
	 **/

	$data = array(
		'post_type' => 'wproto_catalog',
		'taxonomy_name' => 'wproto_catalog_category'
	);
	
	include 'layout.php'; 