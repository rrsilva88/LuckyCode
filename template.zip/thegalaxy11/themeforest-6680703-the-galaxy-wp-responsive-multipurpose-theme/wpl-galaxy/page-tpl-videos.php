<?php
	/**
	 * Template name: 5. Videos
	 **/

	$data = array(
		'post_type' => 'wproto_video',
		'taxonomy_name' => 'wproto_video_category'
	);
	
	include 'layout.php'; 