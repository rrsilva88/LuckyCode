<?php

$override_widget = WP_PLUGIN_DIR . '/woocommerce/classes/widgets/class-wc-widget-best-sellers.php';

if( class_exists( 'woocommerce' ) && file_exists( $override_widget ) ) {
	
	require_once( $override_widget );
	
	if( class_exists('WC_Widget_Best_Sellers') ) {

		class wpl_galaxy_wp_woo_best_sellers_widget extends WC_Widget_Best_Sellers {
	
			function widget( $args, $instance ) {

				global $woocommerce;

				$cache = wp_cache_get('widget_best_sellers', 'widget');

				if ( !is_array($cache) ) $cache = array();

				if ( isset($cache[$args['widget_id']]) ) {
					echo $cache[$args['widget_id']];
					return;
				}

				ob_start();
				extract($args);

				$title = apply_filters('widget_title', empty($instance['title']) ? __('Best Sellers', 'woocommerce' ) : $instance['title'], $instance, $this->id_base);
				if ( !$number = (int) $instance['number'] )
					$number = 10;
				else if ( $number < 1 )
					$number = 1;
				else if ( $number > 15 )
					$number = 15;

    			$query_args = array(
    				'posts_per_page' => $number,
    				'post_status' 	 => 'publish',
    				'post_type' 	 => 'product',
    				'meta_key' 		 => 'total_sales',
    				'orderby' 		 => 'meta_value_num',
    				'no_found_rows'  => 1,
   				);

    			$query_args['meta_query'] = $woocommerce->query->get_meta_query();

    			if ( isset( $instance['hide_free'] ) && 1 == $instance['hide_free'] ) {
    				$query_args['meta_query'][] = array(
			    		'key'     => '_price',
			    		'value'   => 0,
			    		'compare' => '>',
			    		'type'    => 'DECIMAL',
						);
    			}

				$r = new WP_Query($query_args);

				if ( $r->have_posts() ) {

					echo $before_widget;

					if ( $title )
						echo $before_title . $title . $after_title;

						echo '<div class="items">';

					$i=0;
					while ( $r->have_posts()) {
						$r->the_post();
						$i++;
						global $product;

						$thumb_size = wpl_galaxy_wp_utils::is_retina() ? 'photo-small-2x' : 'photo-small';

						?>
						<div class="item">
							<div class="thumbnail">
								<a href="<?php the_permalink(); ?>"><?php echo ( has_post_thumbnail() ? get_the_post_thumbnail( $r->post->ID, $thumb_size ) : woocommerce_placeholder_img( $thumb_size ) ) ?></a>
								<div class="number appear-animation" data-appear-animation-delay="0.15" data-appear-animation="bounceIn"><?php echo $i; ?></div>
							</div>
						
							<div class="description">
						
								<a href="<?php the_permalink(); ?>" class="title"><?php the_title(); ?></a>
								<a href="<?php the_permalink(); ?>" class="price"><?php echo $product->get_price_html(); ?></a>
						
							</div>
						</div>
						<?php
					}
					
					echo '</div>';

					echo $after_widget;
				}

				wp_reset_postdata();

				$content = ob_get_clean();

				if ( isset( $args['widget_id'] ) ) $cache[$args['widget_id']] = $content;

				echo $content;

				wp_cache_set('widget_best_sellers', $cache, 'widget');

			}
		
		}
		
		register_widget('wpl_galaxy_wp_woo_best_sellers_widget');
	
	}
	
}