jQuery.noConflict()( function($){
	"use strict";

	tinymce.create('tinymce.plugins.wproto_column_formatting', {
		createControl : function(id, controlManager) {
			
			if (id == 'wproto_column_formatting_button') {
				
				var t = this;
				
				var menu = controlManager.createMenuButton('wproto_column_formatting_button', {
					title : wprotoVars.mceButtonColumnFormatting,
					//image : wprotoVars.buttonImagePath + '/column_formatting.png',
					icons : false
				});
											
				menu.onRenderMenu.add( function(c, m) {
					m.add({
						title : wprotoVars.strFullWidth,
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('whole');
						}
					});
					m.add({
						title : '1/2',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('half');
						}
					});
					m.add({
						title : '1/3',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('one-third');
						}
					});
					m.add({
						title : '1/4',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('one-quarter');
						}
					});
					m.add({
						title : '2/3',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('two-thirds');
						}
					});
					m.add({
						title : '3/4',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('three-quarters');
						}
					});
					m.add({
						title : '1/5',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('one-fifth');
						}
					});
					m.add({
						title : '2/5',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('two-fifths');
						}
					});
					m.add({
						title : '3/5',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('three-fifths');
						}
					});
					m.add({
						title : '4/5',
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('four-fifths');
						}
					});
					m.add({
						title : wprotoVars.strGoldenLarge,
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-small');
							
							tinyMCE.activeEditor.formatter.toggle('golden-large');
							
						}
					});
					m.add({
						title : wprotoVars.strGoldenSmall,
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							
							tinyMCE.activeEditor.formatter.toggle('golden-small');
						}
					});
					m.add({
						title : wprotoVars.strRemove,
						onclick : function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							tinyMCE.activeEditor.formatter.remove('golden-small');
						}
					});
				});

				return menu;
			}
			
			if (id == 'wproto_remove_column_formatting_button') {
				
				var t = this;
																
				var button = controlManager.createMenuButton('wproto_remove_column_formatting_button', {
						title : wprotoVars.mceButtonRemoveColumnFormatting,
						//image : wprotoVars.buttonImagePath + '/remove_column_formatting.png',
						icons	: false,
						onclick	: function() {
							t._register_formats();
							tinyMCE.activeEditor.formatter.remove('whole');
							tinyMCE.activeEditor.formatter.remove('half');
							tinyMCE.activeEditor.formatter.remove('one-third');
							tinyMCE.activeEditor.formatter.remove('two-thirds');
							tinyMCE.activeEditor.formatter.remove('one-quarter');
							tinyMCE.activeEditor.formatter.remove('three-quarters');
							tinyMCE.activeEditor.formatter.remove('one-fifth');
							tinyMCE.activeEditor.formatter.remove('two-fifths');
							tinyMCE.activeEditor.formatter.remove('three-fifths');
							tinyMCE.activeEditor.formatter.remove('four-fifths');
							tinyMCE.activeEditor.formatter.remove('golden-large');
							tinyMCE.activeEditor.formatter.remove('golden-small');
						}
					});
				return button;
			}
			
			if (id == 'wproto_insert_line_before_button') {
				var button = controlManager.createMenuButton('wproto_insert_line_before_button', {
					title : wprotoVars.mceButtonLineBefore,
					//image : wprotoVars.buttonImagePath + '/line_before.png',
					onclick : function() {
						if(window.tinyMCE) {
							var node = tinyMCE.activeEditor.selection.getNode(),
							parents	= tinyMCE.activeEditor.dom.getParents( node ).reverse(),
							oldestParent = parents[2];
							var blank	= document.createElement('p');
			
							blank.innerHTML = "&nbsp;";
			
							if (typeof oldestParent != "undefined") {
								var n = oldestParent.parentNode.insertBefore( blank, oldestParent );
							} else if (typeof node != "undefined") {
								var n = node.parentNode.insertBefore( blank, node );
							}
							
							tinyMCE.activeEditor.selection.select(n);

						}
					}
				});
				return button;
			}
			
			if (id == 'wproto_insert_line_after_button') {
				var button = controlManager.createMenuButton('wproto_insert_line_after_button', {
					title : wprotoVars.mceButtonLineAfter,
					//image : wprotoVars.buttonImagePath + '/line_after.png',
					onclick : function() {
						if( window.tinyMCE ) {
							var node = tinyMCE.activeEditor.selection.getNode(),
							parents	= tinyMCE.activeEditor.dom.getParents(node).reverse(),
							oldestParent = parents[2];
							var blank = document.createElement('p');
			
							blank.innerHTML = "&nbsp;";
			
							if (typeof oldestParent != "undefined") {
								var n = tinyMCE.activeEditor.dom.insertAfter(blank, oldestParent);
							} else if (typeof node != "undefined") {
								var n = tinyMCE.activeEditor.dom.insertAfter(blank, node);
							}
							
							tinyMCE.activeEditor.selection.select(n);

						}
					}
				});
				return button;
			}
			
			return null;
		},
		_register_formats: function() {
			tinymce.activeEditor.formatter.register(
				'whole',
				{ block: 'div', collapsed : false, classes: 'unit whole', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'half',
				{ block: 'div', collapsed : false, classes: 'unit half', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'one-third',
				{ block: 'div', collapsed : false, classes: 'unit one-third', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'two-thirds',
				{ block: 'div', collapsed : false, classes: 'unit two-thirds', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'one-quarter',
				{ block: 'div', collapsed : false, classes: 'unit one-quarter', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'three-quarters',
				{ block: 'div', collapsed : false, classes: 'unit three-quarters', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'one-fifth',
				{ block: 'div', collapsed : false, classes: 'unit one-fifth', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'two-fifths',
				{ block: 'div', collapsed : false, classes: 'unit two-fifths', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'three-fifths',
				{ block: 'div', collapsed : false, classes: 'unit three-fifths', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'four-fifths',
				{ block: 'div', collapsed : false, classes: 'unit four-fifths', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'golden-small',
				{ block: 'div', collapsed : false, classes: 'unit golden-small', wrapper : true, merge_siblings : false }
			);
			tinymce.activeEditor.formatter.register(
				'golden-large',
				{ block: 'div', collapsed : false, classes: 'unit golden-large', wrapper : true, merge_siblings : false }
			);
   }
	});
	
	tinymce.PluginManager.add( 'wproto_column_formatting', tinymce.plugins.wproto_column_formatting );
	
	var defaultEditor = $('#content');
	if( defaultEditor.length && window.tinymce ) {
		
		setTimeout("try{tinymce.get('content').focus()}catch(e){}", 1000);

	}

});