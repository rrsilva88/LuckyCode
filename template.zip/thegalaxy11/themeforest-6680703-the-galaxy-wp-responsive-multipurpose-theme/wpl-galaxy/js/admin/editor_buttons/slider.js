jQuery.noConflict()( function($){
	"use strict";
	
	var command_name = 'cmd_wproto_slider';
	var plugin_name = 'wproto_insert_slider';
	
	tinymce.create( 'tinymce.plugins.' + plugin_name, {		 
		init : function( ed, url ) {

			// Register the command
			ed.addCommand( command_name, function() {

				var shortcodeText = tinyMCE.activeEditor.selection.getContent();
				var shortcodeSettings = new Object;
				
				var matchArray = null;
				if( ( matchArray = shortcodeText.match(/(id)=["|']{1}(.*?)["|']{1}/i)) != null ) {
					shortcodeSettings.id = matchArray[2];
				} 
				
				$('#wproto-editor-dialog').remove();
				$('<div id="wproto-editor-dialog" title="' + wprotoVars.mceButtonSlider + '"></div>').appendTo('body').hide();
					var dialog = $('#wproto-editor-dialog');
					$.ajax({
						url: ajaxurl,
						type: "post",
						dataType: "json",
						data: {
							'action' : 'wproto_editor_button_form',
							'template' : 'wproto_insert_slider',
							'settings' : shortcodeSettings
						},
						beforeSend: function() {
							dialog.html( wprotoVars.adminBigLoaderImage );

							dialog.dialog({
								height: 220,
								width: 450,
								modal: true,
								buttons: {
									"Ok": function() {

										if( window.tinyMCE ) {

											var id = $('#wproto-layerslider-id').val();
											var insertContent = '[layerslider id="' + id + '"]';
											ed.execCommand( 'mceInsertContent', false, insertContent );
											

										}

										$( this ).dialog( "close" );
                                                                                        
									},
									Cancel: function() {
										$( this ).dialog( "close" );
									}
								}
							});
                                                                
							dialog.css( 'overflowY', 'auto' );
							dialog.parent().parent().find('.ui-dialog-buttonpane').hide();

						},
						success: function( response ) {
							dialog.html( response.html );
							dialog.parent().parent().find('.ui-dialog-buttonpane').show();
						},
						error: function() {
							dialog.dialog( "close" );                               
							wprotoAlertServerResponseError();
						},
						ajaxError: function() {
							dialog.dialog( "close" );                               
							wprotoAlertAjaxError();
						}
					}); 					
		
			});
			

		},
		createControl : function(id, controlManager) {
			if (id == 'wproto_insert_slider') {
				var button = controlManager.createButton('wproto_insert_slider', {
					title : wprotoVars.mceButtonSlider,
					//image : wprotoVars.buttonImagePath + '/slider.png',
					cmd : command_name
				});
				return button;
			}
			return null;
		}
	});

	// Register plugin
	tinymce.PluginManager.add( plugin_name, tinymce.plugins.wproto_insert_slider );

});