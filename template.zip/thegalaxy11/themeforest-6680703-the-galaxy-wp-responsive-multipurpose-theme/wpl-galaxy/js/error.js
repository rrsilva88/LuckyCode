vex.dialog.alert({
	message: wprotoEngineErrorVars.errorStr,
	className: 'vex-theme-default'
});