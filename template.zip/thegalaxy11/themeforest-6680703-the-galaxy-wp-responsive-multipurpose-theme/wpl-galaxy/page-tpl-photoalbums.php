<?php
	/**
	 * Template name: 8. Photo Albums
	 **/

	$data = array(
		'post_type' => 'wproto_photoalbums',
		'taxonomy_name' => 'wproto_photoalbums_category'
	);
	
	include 'layout.php'; 