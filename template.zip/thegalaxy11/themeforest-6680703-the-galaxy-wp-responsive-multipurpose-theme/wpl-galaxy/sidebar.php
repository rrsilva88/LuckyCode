<?php

	wpl_galaxy_wp_front::get_sidebar();