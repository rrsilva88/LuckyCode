<?php
	/**
	 * Template name: 2. Blog
	 **/

	$data = array(
		'post_type' => 'post',
		'taxonomy_name' => 'category'
	);
	
	include 'layout.php'; 