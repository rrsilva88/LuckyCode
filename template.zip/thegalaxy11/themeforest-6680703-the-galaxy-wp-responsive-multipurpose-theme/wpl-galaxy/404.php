<?php get_header(); ?>

	<div id="content" class="wrapper">
		<div class="grid">

			<section class="unit whole">
				
				<div class="post">
				
					<!--
					
						POST HEADER
						
					-->
				
					<header class="post-header">
						<h1 class="post-title"><?php _e('404 - page not found', 'wproto'); ?></h1>
						<?php wpl_galaxy_wp_front::breadcrumbs( true, ' <i class="delimeter"></i> ', true ); ?>
					</header>
					
					<!--
					
						POST CONTENT
						
					-->
					
					<div class="post-content">
						
						<section class="message-404">

							<h1><?php _e('404 error', 'wproto'); ?></h1>
							
							<p><?php _e('We\'re sorry, but the page doesn\'t exist', 'wproto'); ?></p>

						</section>
						
						<div class="search-page-form">
							<div class="inner">
								<form action="<?php echo site_url(); ?>" class="" method="get">
									<fieldset>
										<input type="text" name="s" value="" placeholder="<?php _e('Search request here', 'wproto'); ?>" /> <a href="javascript:;" class="button"><i class="fa fa-search"></i>&nbsp;</a>
									</fieldset>
								</form>
							</div>
						</div>
						
					</div>
					
				</div>
				
			</section>
			
		</div>
	</div> <!-- /content -->

<?php get_footer();