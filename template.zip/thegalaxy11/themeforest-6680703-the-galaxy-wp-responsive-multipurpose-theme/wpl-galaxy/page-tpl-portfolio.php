<?php
	/**
	 * Template name: 3. Portfolio
	 **/

	$data = array(
		'post_type' => 'wproto_portfolio',
		'taxonomy_name' => 'wproto_portfolio_category'
	);
	
	include 'layout.php'; 