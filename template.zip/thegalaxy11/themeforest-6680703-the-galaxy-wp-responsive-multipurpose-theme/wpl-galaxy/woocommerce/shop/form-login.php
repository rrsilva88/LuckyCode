<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce, $wpl_galaxy_wp;
if (is_user_logged_in()) return;
$enable_google_oauth = $wpl_galaxy_wp->get_option( 'enable_google_oauth' );
$enable_facebook_oauth = $wpl_galaxy_wp->get_option( 'enable_facebook_oauth' );
?>
<form method="post" class="login">

	<p class="form-row form-row-first">
		<label for="username"><?php _e( 'Username or email', 'woocommerce' ); ?> <span class="required">*</span></label>
		<input type="text" class="input-text" name="username" id="username" />
	</p>
	<p class="form-row form-row-last">
		<label for="password"><?php _e( 'Password', 'woocommerce' ); ?> <span class="required">*</span></label>
		<input class="input-text" type="password" name="password" id="password" />
	</p>
	<p><?php printf( __( 'Don\'t have account? Proceed to the <strong>Billing</strong> and <strong>Shipping section</strong>. <a href="%s" class="forgot-password">Forgot password?</a>', 'wproto'), esc_url( wp_lostpassword_url( home_url() ) ) ); ?></p>
	<div class="clear"></div>

	<p class="form-row">
		<?php $woocommerce->nonce_field('login', 'login') ?>
		<input type="hidden" name="redirect" value="<?php echo esc_url( $redirect ) ?>" />
		<input type="submit" class="button" name="login" value="<?php _e( 'Login', 'woocommerce' ); ?>" />
		<span class="login-caption"><?php _e('or login with your social account', 'wproto'); ?></span>
		<?php if( $enable_google_oauth == 'yes' ): ?>
		<a href="<?php echo add_query_arg( array( 'wproto_action' => 'oauth-run', 'provider' => 'google' ), home_url() ); ?>" class="button button-google-plus"><i class="fa fa-google-plus"></i> <span class="border"></span> <span class="text"><?php _e( 'Sign in with Google', 'wproto'); ?></span></a>
		<?php endif; ?>
		<?php if( $enable_facebook_oauth == 'yes' ): ?>
		<a href="<?php echo add_query_arg( array( 'wproto_action' => 'oauth-run', 'provider' => 'facebook' ), home_url() ); ?>" class="button button-facebook"><i class="fa fa-facebook"></i> <span class="border"></span> <span class="text"><?php _e( 'Sign in with Facebook', 'wproto'); ?></span></a>
		<?php endif; ?>
	</p>

	<div class="clear"></div>
</form>